package com.cg.ibs.rm.dao;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;
import org.apache.log4j.Logger;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.bean.CustomerBean;
import com.cg.ibs.rm.exception.ExceptionMessages;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.ui.Status;
import com.cg.ibs.rm.util.JpaUtil;

public class CreditCardDAOImpl implements CreditCardDAO {
	private static Logger logger = Logger.getLogger(CreditCardDAOImpl.class);
	private EntityManager manager = JpaUtil.getEntityManger();

	public Set<CreditCard> getDetails(BigInteger uci){
		logger.info("entering into getDetails method of CreditCardDAOImpl class");
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<CreditCard> query = builder.createQuery(CreditCard.class);
		Root<CustomerBean> custRoot = query.from(CustomerBean.class);
		Join<CustomerBean, CreditCard> creditCards = custRoot.join("creditCards");
		query.select(creditCards).where(builder.and(builder.equal(custRoot.get("uci"), uci),
				builder.equal(creditCards.get("cardStatus"), Status.ACTIVE)));
		return new HashSet<>(manager.createQuery(query).getResultList());
	}

	public boolean copyDetails(BigInteger uci, CreditCard card) throws IBSExceptions {// copying details for bank_admin
																						// check
		logger.info("entering into copyDetails method of CreditCardDAOImpl class");
		boolean result = false;
		logger.info("entering into copyDetails method of BeneficiaryDAOImpl class");
		if (manager.find(CreditCard.class, card.getCardNumber()) == null||card.getCardStatus().equals(Status.BLOCKED)) {
			CustomerBean customer = manager.find(CustomerBean.class, uci);
			card.setCustomer(customer);
			manager.persist(card);
			result = true; // must include WHERE
		} else {
			throw new IBSExceptions(ExceptionMessages.ERROR1);
		}
		return result;

	}

	@Override
	public boolean deleteDetails(BigInteger cardNumber) throws IBSExceptions {//delete method for customer use
		logger.info("entering into deleteDetails method of BeneficiaryDAOImpl class");
		boolean check = false;
		CreditCard card = manager.find(CreditCard.class, cardNumber);
		if ((null != card)&&(card.getCardStatus().equals(Status.ACTIVE))) {
			manager.remove(card);
			check = true;
		} else {
			throw new IBSExceptions(ExceptionMessages.ERROR2);
		}
		return check;
	}
}