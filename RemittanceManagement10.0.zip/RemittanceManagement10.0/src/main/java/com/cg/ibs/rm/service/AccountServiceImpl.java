package com.cg.ibs.rm.service;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import com.cg.ibs.rm.bean.AccountBean;
import com.cg.ibs.rm.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService{
	private AccountDaoImpl accountdao = new AccountDaoImpl();
	@Override
	public Set<AccountBean> getAccountsOfUci(BigInteger uci) {
		return new HashSet<>(accountdao.getAccounts(uci));
	}
	
}
