package com.cg.ibs.rm.dao;

import java.math.BigInteger;
import java.util.Set;

public interface CustomerDAO {
	public Set<BigInteger> getUciList();

	public String returnName(BigInteger uci);
}
