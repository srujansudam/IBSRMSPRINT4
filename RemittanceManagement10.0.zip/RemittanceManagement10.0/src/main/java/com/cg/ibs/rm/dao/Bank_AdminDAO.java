package com.cg.ibs.rm.dao;

import java.math.BigInteger;
import java.util.Set;

import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.exception.IBSExceptions;

public interface Bank_AdminDAO {
	public Set<BigInteger> getRequests();

	public Set<CreditCard> getCreditCardDetails(BigInteger uci);

	public Set<Beneficiary> getBeneficiaryDetails(BigInteger uci);

	public boolean checkedCreditCardDetails(CreditCard card) throws IBSExceptions;

	public boolean checkedBeneficiaryDetails(Beneficiary beneficiary) throws IBSExceptions;
	
	public boolean decliningCreditCardDetails(CreditCard card) throws IBSExceptions;
	
	public boolean decliningBeneficiaryDetails(Beneficiary beneficiary) throws IBSExceptions;
}
