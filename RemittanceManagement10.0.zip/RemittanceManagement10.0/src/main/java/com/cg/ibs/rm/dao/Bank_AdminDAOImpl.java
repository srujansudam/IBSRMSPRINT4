package com.cg.ibs.rm.dao;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import org.apache.log4j.Logger;

import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.bean.CustomerBean;
import com.cg.ibs.rm.exception.ExceptionMessages;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.ui.Status;
import com.cg.ibs.rm.util.JpaUtil;

public class Bank_AdminDAOImpl implements Bank_AdminDAO {
	private static Logger logger = Logger.getLogger(Bank_AdminDAOImpl.class);
	EntityManager manager = JpaUtil.getEntityManger();

	public Set<BigInteger> getRequests() {
		logger.info("entering into getRequests method of BankRepresentativeDAOImpl class");
		Set<BigInteger> ucis = new HashSet<>();
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<BigInteger> query = builder.createQuery(BigInteger.class);

		Root<CustomerBean> custRoot = query.from(CustomerBean.class);
		Join<CustomerBean, CreditCard> creditCards = custRoot.join("creditCards");
		query.select(custRoot.<BigInteger>get("uci")).where(builder.equal(creditCards.get("cardStatus"), Status.PENDING));
		ucis.addAll(new HashSet<BigInteger>(manager.createQuery(query).getResultList()));

		CriteriaQuery<BigInteger> query2 = builder.createQuery(BigInteger.class);
		Root<CustomerBean> custRoot2 = query2.from(CustomerBean.class);
		Join<CustomerBean, Beneficiary> beneficiaries = custRoot2.join("beneficiaries");
		query2.select(custRoot2.<BigInteger>get("uci")).where(builder.equal(beneficiaries.get("status"), Status.PENDING));
		ucis.addAll(new HashSet<BigInteger>(manager.createQuery(query2).getResultList()));

		return ucis;
	}

	public Set<CreditCard> getCreditCardDetails(BigInteger uci) {// credit cards list which goes to bank admin
		logger.info("entering into getCreditCardDetails method of BankRepresentativeDAOImpl class");
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<CreditCard> query = builder.createQuery(CreditCard.class);
		Root<CustomerBean> custRoot = query.from(CustomerBean.class);
		Join<CustomerBean, CreditCard> unapprovedCreditCards = custRoot.join("creditCards");
		query.select(unapprovedCreditCards).where(builder.and(builder.equal(custRoot.get("uci"), uci),
				builder.equal(unapprovedCreditCards.get("cardStatus"), Status.PENDING)));
		return new HashSet<>(manager.createQuery(query).getResultList());
	}

	public Set<Beneficiary> getBeneficiaryDetails(BigInteger uci) {// beneficiary list which goes to bank admin
		logger.info("entering into getBeneficiaryDetails method of BankRepresentativeDAOImpl class");
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Beneficiary> query = builder.createQuery(Beneficiary.class);
		Root<CustomerBean> custRoot = query.from(CustomerBean.class);
		Join<CustomerBean, Beneficiary> unapprovedBeneficiaries = custRoot.join("beneficiaries");
		query.select(unapprovedBeneficiaries).where(builder.and(builder.equal(custRoot.get("uci"), uci),
				builder.equal(unapprovedBeneficiaries.get("status"), Status.PENDING)));
		return new HashSet<>(manager.createQuery(query).getResultList());
	}

	@Override
	public boolean checkedCreditCardDetails(CreditCard card) throws IBSExceptions {//bank admin gives his approval/disapproval
		logger.info("entering into copyCreditCardDetails method of BankRepresentativeDAOImpl class");
		boolean check = false;
		CreditCard cardCheck = manager.find(CreditCard.class, card.getCardNumber());
		if ((cardCheck != null) && (cardCheck.getCardStatus().equals(Status.PENDING))) {
			cardCheck.setCardStatus(Status.ACTIVE);
			manager.merge(cardCheck);
			check = true;
		} else {
			throw new IBSExceptions(ExceptionMessages.ERROR2);
		}
		return check;
	}
	
	@Override
	public boolean decliningCreditCardDetails(CreditCard card) throws IBSExceptions {//bank admin gives his approval/disapproval
		logger.info("entering into copyCreditCardDetails method of BankRepresentativeDAOImpl class");
		boolean check = false;
		CreditCard cardCheck = manager.find(CreditCard.class, card.getCardNumber());
		if ((cardCheck != null) && (cardCheck.getCardStatus().equals(Status.PENDING))) {
			cardCheck.setCardStatus(Status.BLOCKED);
			manager.merge(cardCheck);
			check = true;
		} else {
			throw new IBSExceptions(ExceptionMessages.ERROR2);
		}
		return check;
	}

	@Override
	public boolean checkedBeneficiaryDetails(Beneficiary beneficiary) throws IBSExceptions {//bank admin gives his approval/disapproval
		logger.info("entering into copyBeneficiaryDetails method of BankRepresentativeDAOImpl class");
		boolean result = false;
		Beneficiary beneficiaryCheck = manager.find(Beneficiary.class, beneficiary.getAccountNumber());
		if ((beneficiaryCheck != null) && (beneficiaryCheck.getStatus().equals(Status.PENDING))) {
			beneficiaryCheck.setStatus(Status.ACTIVE);
			manager.merge(beneficiaryCheck);
			result = true;
		} else {
			throw new IBSExceptions(ExceptionMessages.BENEFICIARY_DOESNT_EXIST);
		}
		return result;
	}
	
	@Override
	public boolean decliningBeneficiaryDetails(Beneficiary beneficiary) throws IBSExceptions {//bank admin gives his approval/disapproval
		logger.info("entering into copyCreditCardDetails method of BankRepresentativeDAOImpl class");
		boolean result = false;
		Beneficiary beneficiaryCheck = manager.find(Beneficiary.class, beneficiary.getAccountNumber());
		if ((beneficiaryCheck != null) && (beneficiaryCheck.getStatus().equals(Status.PENDING))) {
			beneficiaryCheck.setStatus(Status.BLOCKED);
			manager.merge(beneficiaryCheck);
			result = true;
		} else {
			throw new IBSExceptions(ExceptionMessages.BENEFICIARY_DOESNT_EXIST);
		}
		return result;
	}

}
