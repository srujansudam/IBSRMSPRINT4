package com.cg.ibs.rm.service;

import java.math.BigInteger;

public interface CustomerService {

	public boolean checkUciList(BigInteger uci);

	public String returnName(BigInteger uci);
}
