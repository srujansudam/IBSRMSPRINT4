package com.cg.ibs.rm.dao;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.cg.ibs.rm.bean.CustomerBean;
import com.cg.ibs.rm.util.JpaUtil;

public class CustomerDAOImpl {
	EntityManager manager = JpaUtil.getEntityManger();

	public String returnName(BigInteger uci) {
		CustomerBean customerBean = manager.find(CustomerBean.class, uci);
		String name = customerBean.getFirstName() + " " + customerBean.getLastname();
		return name;
	}

	public Set<BigInteger> getUciList() {
		Set<BigInteger> ucis = new HashSet<>();
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<BigInteger> query = builder.createQuery(BigInteger.class);
		Root<CustomerBean> custRoot = query.from(CustomerBean.class);
		query.select(custRoot.<BigInteger>get("uci"));
		ucis.addAll(new HashSet<BigInteger>(manager.createQuery(query).getResultList()));
		return ucis;
	}

}
