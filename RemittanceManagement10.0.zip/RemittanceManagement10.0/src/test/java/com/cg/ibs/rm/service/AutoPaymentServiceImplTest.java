
package com.cg.ibs.rm.service;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.junit.jupiter.api.Test;

import com.cg.ibs.rm.bean.AutoPayment;
import com.cg.ibs.rm.bean.ServiceProviderId;
import com.cg.ibs.rm.exception.IBSExceptions;

class AutoPaymentServiceImplTest {
	AutoPaymentServiceImpl autoPaymentServiceImpl = new AutoPaymentServiceImpl();

	@Test
	public void autoDeductionTest2() {
		AutoPayment autoPayment = new AutoPayment(
				new ServiceProviderId(new BigInteger("1001"), new BigInteger("5555111151513301")), new BigDecimal("100"),
				"12/12/2019");
		try {
			assertTrue(autoPaymentServiceImpl.autoDeduction(new BigInteger("5555111151513301"), new BigInteger("11111111111"),
					autoPayment));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Auto payment service has already been opted.", throwable.getMessage());
		}

	}

	@Test
	public void autoDeductionTest3() {
		AutoPayment autoPayment = new AutoPayment(
				new ServiceProviderId(new BigInteger("1001"), new BigInteger("5555111151513301")), new BigDecimal("100"),
				"12/12/2019");
		try {
			assertTrue((autoPaymentServiceImpl.autoDeduction(new BigInteger("5555111151513301"), new BigInteger("11111111111"),
					autoPayment)));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Auto payment service has already been opted.", throwable.getMessage());
		}

	}

	@Test
	public void updateRequirementsTest1() {
		try {
			assertTrue(autoPaymentServiceImpl.updateRequirements(new BigInteger("5555111151513301"),
					new BigInteger("1000001")));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Auto payment service doesn't exist", throwable.getMessage());
		}
	}

	@Test
	public void updateRequirementsTest2() {
		try {
			assertFalse((autoPaymentServiceImpl.updateRequirements(new BigInteger("5555111151513301"),
					new BigInteger("3"))));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Auto payment service doesn't exist", throwable.getMessage());
		}
	}

	@Test
	public void updateRequirementsTest3() {
		try {
			assertEquals(true, (autoPaymentServiceImpl.updateRequirements(new BigInteger("5555111151513301"),
					new BigInteger("3"))));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Auto payment service doesn't exist", throwable.getMessage());
		}
	}

	@Test
	public void showAutopaymentDetailsTest() {
		assertNotNull(autoPaymentServiceImpl.showAutopaymentDetails(new BigInteger("5555111151513301")));
	}

	@Test
	public void showIBSServiceProvidersTest() {
		assertEquals(1, autoPaymentServiceImpl.showIBSServiceProviders().size());
	}

}